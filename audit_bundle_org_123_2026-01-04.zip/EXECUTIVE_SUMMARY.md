# Audit Executive Summary

## Overview
- **Total Events**: 2
- **Violations Detected**: 1
- **Remediations Executed**: 2

## Evidence Records
This bundle contains 2 evidence records covering compliance events, violations, and remediations.

## Audit Trail
The audit trail includes a hash-chained log of all evidence records, ensuring tamper-evident history.

## Verification
Run the verification script to confirm the integrity of the audit trail.
